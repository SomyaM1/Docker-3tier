# 🐳 Docker 3-Tier Application — FiftyFive Technologies

A fully containerised **Nginx → Node.js → MySQL** stack built for the FiftyFive Technologies DevOps Intern assessment.

---

## Architecture Diagram

```
                        ┌─────────────────────────────────────────────────┐
                        │              Docker custom network               │
                        │                   app_network                   │
                        │                                                  │
  ┌──────────┐  :80     │  ┌──────────────────┐      ┌───────────────┐   │
  │  Browser │ ──────────▶ │  frontend (Nginx) │      │   db (MySQL)  │   │
  └──────────┘          │  │   nginx:alpine    │      │   mysql:8.0   │   │
                        │  │                  │      │   port 3306   │   │
                        │  │  / → index.html  │      │               │   │
                        │  │  /api/* → proxy  │      │  Named volume │   │
                        │  └────────┬─────────┘      │  mysql_data   │   │
                        │           │ /api/           └───────┲───────┘   │
                        │           ▼                         ┃           │
                        │  ┌──────────────────┐               ┃           │
                        │  │ backend (Node.js) │───────────────┛           │
                        │  │  node:20-alpine   │  mysql2/promise pool      │
                        │  │   port 3000       │                           │
                        │  │                  │                           │
                        │  │  GET /           │                           │
                        │  │  GET /health     │                           │
                        │  │  GET /db-info    │                           │
                        │  └──────────────────┘                           │
                        └─────────────────────────────────────────────────┘
```

---

## Setup Instructions

### Prerequisites
- Docker Engine ≥ 24
- Docker Compose plugin v2 (`docker compose` not `docker-compose`)

### One-command startup

```bash
# 1. Clone the repo
git clone <your-repo-url>
cd docker-3tier

# 2. Create your env file from the example
cp .env.example .env
# Edit .env and set secure passwords if desired

# 3. Build and start all services
docker compose up --build
```

Open **http://localhost** in your browser.

---

## Explanation

### How the backend waits for MySQL

Two complementary mechanisms are used — neither alone is sufficient:

1. **`depends_on` with `condition: service_healthy`** in `docker-compose.yml` — Compose will not start the backend container until MySQL's `healthcheck` (`mysqladmin ping`) returns healthy.

2. **`wait-for-mysql.sh`** inside the backend container — this shell script polls `nc -z $DB_HOST 3306` once per second (up to 60 attempts) before exec-ing `node server.js`. This guards against the race where the TCP port opens before MySQL is truly ready.

The `mysql2` connection pool also reconnects automatically if the database drops mid-run, so transient failures are handled at the application layer too.

### How Nginx gets the backend URL

The nginx config is **not baked at build time**. Instead:

1. `frontend/nginx.conf.template` contains the placeholder `${BACKEND_URL}`.
2. `frontend/entrypoint.sh` runs `envsubst '${BACKEND_URL}'` at container startup, writing the rendered config to `/etc/nginx/conf.d/default.conf`.
3. The `BACKEND_URL` value (`http://backend:3000`) is supplied via the `environment` section of `docker-compose.yml`, which reads it from `.env`.

This means no backend IP or hostname is ever hardcoded in any image layer.

### How services communicate

All three containers share the custom bridge network `app_network`. Docker's built-in DNS resolves service names (`frontend`, `backend`, `db`) to their container IPs automatically. No IP addresses are used anywhere in the configuration.

---

## Testing Steps

### Access the frontend

```
http://localhost
```

The page shows live health indicators and lets you hit each API endpoint.

### Hit the API through Nginx proxy

```bash
# Root ping
curl http://localhost/api/

# Database health check
curl http://localhost/api/health

# DB version + server time
curl http://localhost/api/db-info
```

### View all service logs

```bash
docker compose logs -f
# or per service:
docker compose logs -f backend
docker compose logs -f db
docker compose logs -f frontend
```

### Check health statuses

```bash
docker compose ps
```

---

## Failure Scenario — MySQL Restart

### What happens

1. `docker restart ff_db` (or `docker compose restart db`) stops the MySQL container.
2. The backend's `mysql2` connection pool starts receiving connection errors immediately. Requests to `/health` and `/db-info` will return `503 { "database": "error" }`.
3. The frontend health indicator turns **red** for MySQL. The backend indicator stays **green** (Node process is still running).
4. MySQL restarts and runs its health check (`mysqladmin ping`). Once healthy, the backend's connection pool automatically re-establishes connections on the next query — no backend restart required.

### Recovery time

Typically **10–20 seconds**:
- MySQL needs ~5–10 s to restart and accept connections.
- The `mysql2` pool reconnects on the next incoming request.
- No manual intervention is needed.

### How to test it

```bash
# In one terminal — watch health endpoint
watch -n 1 'curl -s http://localhost/api/health | python3 -m json.tool'

# In another terminal — restart MySQL
docker restart ff_db
```

---

## Bonus Features

| Feature | Implementation |
|---|---|
| **Multi-stage builds** | Both `backend/Dockerfile` and `frontend/Dockerfile` use multi-stage builds — a `deps`/build stage installs dependencies, the final stage copies only what's needed |
| **Non-root USER** | Both Dockerfiles create a dedicated `appuser` in group `appgroup` and switch to it before `EXPOSE`/`CMD` |

---

## Repository Structure

```
.
├── frontend/
│   ├── Dockerfile            # Multi-stage, non-root
│   ├── nginx.conf.template   # ${BACKEND_URL} placeholder
│   ├── entrypoint.sh         # Runs envsubst then nginx
│   ├── index.html            # Static UI with live health checks
│   └── .dockerignore
├── backend/
│   ├── Dockerfile            # Multi-stage, non-root
│   ├── server.js             # Node.js REST API
│   ├── package.json
│   ├── wait-for-mysql.sh     # TCP-level MySQL readiness probe
│   └── .dockerignore
├── db/
│   └── init.sql              # Creates DB, user, tables on first run
├── docker-compose.yml
├── .env.example              # ← commit this
├── .gitignore                # .env is ignored
└── README.md
```
