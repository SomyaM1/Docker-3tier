const http = require('http');
const mysql = require('mysql2/promise');

const PORT = process.env.PORT || 3000;
const DB_HOST = process.env.DB_HOST || 'db';
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);
const DB_USER = process.env.DB_USER || 'appuser';
const DB_PASS = process.env.DB_PASSWORD || 'apppassword';
const DB_NAME = process.env.DB_NAME || 'appdb';

// ── Connection pool (lazy, reconnects automatically) ─────────────────────
let pool = null;

function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: DB_HOST,
      port: DB_PORT,
      user: DB_USER,
      password: DB_PASS,
      database: DB_NAME,
      waitForConnections: true,
      connectionLimit: 5,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 10000,
    });
  }
  return pool;
}

// ── Helpers ───────────────────────────────────────────────────────────────
function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data),
  });
  res.end(data);
}

async function dbPing() {
  const conn = await getPool().getConnection();
  try {
    await conn.ping();
    return true;
  } finally {
    conn.release();
  }
}

// ── Routes ────────────────────────────────────────────────────────────────
async function router(req, res) {
  console.log(`[backend] ${req.method} ${req.url}`);

  if (req.method === 'GET' && req.url === '/') {
    return send(res, 200, { status: 'ok', service: 'backend-api', timestamp: new Date().toISOString() });
  }

  if (req.method === 'GET' && req.url === '/health') {
    try {
      await dbPing();
      return send(res, 200, { status: 'healthy', database: 'ok' });
    } catch (err) {
      console.error('[backend] health check DB error:', err.message);
      return send(res, 503, { status: 'unhealthy', database: 'error', error: err.message });
    }
  }

  if (req.method === 'GET' && req.url === '/db-info') {
    try {
      const [[row]] = await getPool().query('SELECT VERSION() AS version, NOW() AS server_time, DATABASE() AS db');
      return send(res, 200, { database: 'ok', ...row });
    } catch (err) {
      console.error('[backend] db-info error:', err.message);
      return send(res, 503, { database: 'error', error: err.message });
    }
  }

  return send(res, 404, { error: 'Not found' });
}

// ── Server ────────────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  router(req, res).catch(err => {
    console.error('[backend] unhandled error:', err);
    send(res, 500, { error: 'Internal server error' });
  });
});

server.listen(PORT, () => {
  console.log(`[backend] listening on :${PORT}`);
  console.log(`[backend] DB target: ${DB_HOST}:${DB_PORT}/${DB_NAME}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[backend] SIGTERM received, shutting down gracefully');
  server.close(() => {
    if (pool) pool.end();
    process.exit(0);
  });
});
