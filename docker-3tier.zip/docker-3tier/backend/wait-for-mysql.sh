#!/bin/sh
# wait-for-mysql.sh — poll MySQL until it accepts connections, then start the app
# Usage: ./wait-for-mysql.sh HOST PORT MAX_TRIES CMD [args...]

HOST="${1:-db}"
PORT="${2:-3306}"
MAX_TRIES="${3:-60}"
shift 3

echo "[wait-for-mysql] waiting for ${HOST}:${PORT} (max ${MAX_TRIES}s)..."

i=0
until nc -z "$HOST" "$PORT" 2>/dev/null; do
  i=$((i + 1))
  if [ "$i" -ge "$MAX_TRIES" ]; then
    echo "[wait-for-mysql] ERROR: MySQL not ready after ${MAX_TRIES}s — aborting"
    exit 1
  fi
  echo "[wait-for-mysql] attempt ${i}/${MAX_TRIES} — sleeping 1s..."
  sleep 1
done

echo "[wait-for-mysql] MySQL is accepting connections on ${HOST}:${PORT}"

# Extra 2s grace period for MySQL to finish initialising after port opens
sleep 2

exec "$@"
