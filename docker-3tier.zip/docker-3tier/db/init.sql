-- Runs once on first container start (mounted via docker-compose)
CREATE DATABASE IF NOT EXISTS `appdb`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create application user with limited privileges
CREATE USER IF NOT EXISTS 'appuser'@'%' IDENTIFIED BY 'apppassword';
GRANT SELECT, INSERT, UPDATE, DELETE ON `appdb`.* TO 'appuser'@'%';

USE appdb;

CREATE TABLE IF NOT EXISTS health_log (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

FLUSH PRIVILEGES;
