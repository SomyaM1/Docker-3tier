#!/bin/sh
set -e

# Inject BACKEND_URL into nginx config at container start (not build time)
envsubst '${BACKEND_URL}' \
  < /etc/nginx/templates/nginx.conf.template \
  > /etc/nginx/conf.d/default.conf

echo "[frontend] nginx config generated with BACKEND_URL=${BACKEND_URL}"

exec nginx -g "daemon off;"
